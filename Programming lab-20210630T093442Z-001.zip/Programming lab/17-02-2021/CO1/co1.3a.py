list1=[1,-1,2,-5,9,-2,-54,87,-33,-76,24,-67]
pos=list()
for i in list1:
    if i>0:
        pos.append(i)
print('Original list:',list1)
print('Positive integer list:',pos)