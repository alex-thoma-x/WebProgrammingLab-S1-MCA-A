def area(r):
    print('Area of sphere with radius',r,'is:','%.2f'%(4*(3.14*r*r)),'Sq.units')
def perimeter(r):
    print('Perimeter of (great circle of) sphere with radius',r,'is:','%.2f'%(2*3.14*r),'units')
