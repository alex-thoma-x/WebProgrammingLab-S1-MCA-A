def area(l,b,h):
    print('Total surface area of cuboid with dimensions',l,',',b,',',h,'is:','%.2f'%(2*((l*b)+(b*h)+(l*h))),'Sq.units')
def perimeter(l,b,h):
    print('Perimeter of cuboid with dimensions', l, ',', b, ',', h, 'is:','%.2f'%(4*(l+b+h)),'units')
