def area(a,b):
    print('Area of rectangle with sides',a,'and',b,'is: ','%.2f'%(a*b),'Sq.units')
def perimeter(a,b):
    print('Perimeter of rectangle with sides',a,'and',b,'is:','%.2f'%(2*(a+b)),'units')
